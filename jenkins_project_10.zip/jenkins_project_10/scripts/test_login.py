class TestLogin:

    def test_login1(self):
        print("test_login1")
        assert 1

    def test_login2(self):
        print("test_login2")
        assert 0

    def test_login3(self):
        print("test_login3")
        assert 1
